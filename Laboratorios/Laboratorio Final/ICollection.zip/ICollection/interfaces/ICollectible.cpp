
#include "ICollectible.h"

ICollectible::ICollectible(){
    
}

ICollectible::~ICollectible()
{
    
}