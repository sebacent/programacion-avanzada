//#include"lab0.h"
#include<stdio.h>
#include<iostream>
#include "Empresa.h"
#include "Paga.h"
#include "Fijo.h"
#include "Jornalero.h"
#include "Empleado.h"




using namespace std;






// ------ INICIO ------------------------------ FUNCIONES EMPLEADO --------------------------------

// empresa::empresa(string nombre,string nombre_legal,int rut,empleado emp,int nro){
//     this->nombre = nombre;
//     this->nombre_legal = nombre_legal;
//     this->rut=rut;
//     this->empleados[nro]=emp;

// }




// ------ INICIO ------------------------------- FUNCIONES EMPRESA --------------------------------


int main(){ 
    // LOS ERRORES QUE TIENE ES PORQUE NO ESTAN COMPILADOS LOS .CPP DE CADA CLASE 
    // HAY QUE VER COMO SE COMPILA CADA CPP Y COMO EJECUTAR ESTE 
    // https://stackoverflow.com/questions/43447960/error-message-undefined-reference-error-to-in-c



    // FALTA:MENU, POR LO TANTO TAMBIEN MANEJO DE EXCEPCIONES, SOBRECARGA, CARGAR ARRAYS DE PUNTEROS CON EMPLEADOS
    Empresa pruebaEmpresa = Empresa();
    
    string nombre_empleado = " JORGE";
    string nombre_legal = " EMRESARIO";
    string ci = "50151411";
    int edad = 22;
    Paga valor = Paga(129,US);
    int rut = 158451;

    Empleado* emp = new Empleado(nombre_empleado,ci,edad,valor,&pruebaEmpresa);
    emp->imprimirEmpleado();
    
    ci = "8888888";
    nombre_empleado = " RAUL";
    Fijo* fij = new Fijo(nombre_empleado, ci, edad, valor,&pruebaEmpresa);
    fij->imprimirEmpleado();


    Paga val2 = Paga(129,US);
    ci = "99999999";
    nombre_empleado = " PEDRO";
    Jornalero* jorna = new Jornalero(nombre_empleado, ci, edad, val2,&pruebaEmpresa);
    jorna->setHoras(100);
    jorna->imprimirEmpleado();

    pruebaEmpresa.AddEmpleado(emp);
    pruebaEmpresa.AddEmpleado(fij);
    pruebaEmpresa.AddEmpleado(jorna);
    pruebaEmpresa.listarEmpleados();    



}





