#include "Empleado.h"
#include <string>
#include <iostream>

using namespace std;
Empleado::Empleado(){};
Empleado::~Empleado(){};
void Empleado::setNombre(string nombre){
    this->nombre = nombre;
}
void Empleado::setCi(string ci){
    this->ci = ci;
}
void Empleado::setValorHora(Paga valorHora){
    this->valorHora = valorHora;
}
void Empleado::setEdad(int edad){
    this->edad = edad;
}

string Empleado::getNombre(){
    return this->nombre;
}

string Empleado::getCi(){
    return this->ci;
}

Paga Empleado::getValorHora(){
    return this->valorHora;
}

int Empleado::getEdad(){
    return this->edad;
}

void Empleado::setEmpresa(Empresa * miemp){
    this->miemp=miemp;
}


Empleado::Empleado(string nombre, string ci, int edad, Paga valorHora, Empresa *miemp){
    this->nombre = nombre;
    this->ci = ci;
    this->edad = edad;
    this->valorHora = valorHora;
    this->miemp=miemp;
}

//DEBERIAN DE EXISTIR ESTAS 2?????? YA LAS TENGO EN SUS HIJOS
float Empleado::getSueldoPeso(){
    Paga valorHora = this->getValorHora();
    if(valorHora.getMoneda() == 0){  //SI ES USD
        return 40 * Cambio::aPeso(valorHora.getMonto());
    } else {
        return 40 * valorHora.getMonto();
    }
}

float Empleado::getSueldoDolar(){
    Paga valorHora = this->getValorHora();
    if(valorHora.getMoneda() == 0){  //SI ES USD
        return 40 * valorHora.getMonto();
    } else {
        return 40 * Cambio::aDolar(valorHora.getMonto());
    }
}

void Empleado::imprimirEmpleado(){
    string nombre = this->getNombre();
    string ci = this->getCi();
    int edad = this->getEdad();
    Paga valorHora = this->getValorHora();
    float sueldo =  valorHora.getMonto();
    float sueldoPeso = this->getSueldoPeso();
    float sueldoDolar = this->getSueldoDolar();
    //INICIO -------------DEBUG
    
    // cout << "Valor Hora: " << sueldo <<endl;
    // cout << "Valor Peso: " << sueldoPeso << endl;
    // cout << "Valor Dolar: " << sueldoDolar << endl;

    //FIN -------------DEBUG
    cout << "---------------------------------- "<<endl;  
    cout << "INFORMACION DEL EMPLEADO: "<<endl;  

    cout << "CI: " <<ci<<endl;
    cout << "Nombre: " <<nombre<<endl;
    cout << "Edad: " <<edad<<endl;
    // cout << "Valor Hora: " <<30 <<endl;
    // cout << "Valor Peso: " << 10 << endl;
    // cout << "Valor Dolar: " << 20 << endl;
    cout << "Empresa, Nombre: " << this->miemp->getNombre() << endl;
    cout << "Empresa, Nombre Legal:  " << this->miemp->getNombreLegal() << endl;
    cout << "---------------------------------- "<<endl;  
}

// ------ FIN ------------------------------- FUNCIONES EMPLEADO --------------------------------


// VA TODO EN UN MISMO .h Y .cpp (NO LOGRE QUE FUNCIONARA DE OTRA FORMA)


// ------ INICIO ------------------------------- FUNCIONES JORNALERO --------------------------------
Jornalero::Jornalero(std::string nombre, std::string ci, int edad, Paga valorHoras, Empresa *miemp){
    setNombre(nombre);
    setCi(ci);
    setEdad(edad);
    setValorHora(valorHoras);
    setEmpresa(miemp);
}
Jornalero::~Jornalero(){}

float Jornalero::getSueldoPeso(){
    Paga valorHora = this->getValorHora();
    if(valorHora.getMoneda() == 0){  //SI ES USD
        return this->getHoras() * Cambio::aPeso(valorHora.getMonto());
    } else {
        return this->getHoras() * valorHora.getMonto();
    }
    
}

float Jornalero::getSueldoDolar(){
    Paga valorHora = this->getValorHora();
    if(valorHora.getMoneda() == 0){  //SI ES USD
        return this->getHoras() * valorHora.getMonto();
    } else {
        return this->getHoras() * Cambio::aDolar(valorHora.getMonto());
    }
    
}  


void Jornalero::setHoras(int horas){ 
    this->horas = horas;
}

int Jornalero::getHoras(){
    return this->horas;
}
// ------ FIN ------------------------------- FUNCIONES JORNALERO --------------------------------



// ------ INICIO ------------------------------- FUNCIONES FIJO --------------------------------
Fijo::Fijo(std::string nombre, std::string ci, int edad, Paga valorPaga, Empresa *miemp){
    setNombre(nombre);
    setCi(ci);
    setEdad(edad);
    setValorHora(valorPaga);
    setEmpresa(miemp);
    // if(int i=miemp->getCantEmpleados()< MAX_EMPLEADOS){
    //     miemp->misempleados[i+1]=;
    //     miemp->setCantEmpleados();
    // }
}
Fijo::~Fijo(){}

float Fijo::getSueldoPeso(){
    Paga valorHora = this->getValorHora();
    if(valorHora.getMoneda() == 0){  //SI ES USD
        return 40 * Cambio::aPeso(valorHora.getMonto());
    } else {
        return 40 * valorHora.getMonto();
    }
    
}

float Fijo::getSueldoDolar(){
    Paga valorHora = this->getValorHora();
    if(valorHora.getMoneda() == 0){  //SI ES USD
        return 40 * valorHora.getMonto();
    } else {
        return 40 * Cambio::aDolar(valorHora.getMonto());
    }

    
}  



// ------ FIN ------------------------------- FUNCIONES FIJO --------------------------------