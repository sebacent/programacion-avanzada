#include "Paga.h"
#include <iostream>
#include <stdio.h>

// ------ INICIO ------------------------------ FUNCIONES CAMBIO --------------------------------

double Cambio::aPeso(double paga){
    std::cout<< "RECIBO"<< paga<<std::endl;
    std::cout<< "DEVUELVO"<< paga * 40.15<<std::endl;
    return paga * cUSD;
}

float Cambio::aDolar(float paga){
    return paga / cUSD;

}

// Paga Cambio::aPeso(Paga paga) {
//     if (paga.getMoneda() == Moneda::USD) {
//         return Paga(Cambio::aPeso(paga.getMonto()), Moneda::US);
//     }else {
//         return paga;
//     }
// }
// ------ FIN ------------------------------ FUNCIONES PAGA  --------------------------------

// ------ INICIO ------------------------------ FUNCIONES PAGA --------------------------------
Paga::Paga(){
    this->monto = 250;
    this->moneda = US;

}
Paga::Paga(float monto, Moneda moneda){
    this->monto = monto; 
    this->moneda = moneda;
}

 Paga::~Paga(){};

float Paga::getMonto(){
    return this->monto;
}

void Paga::setMonto(float monto){
    this->monto = monto;
}

Moneda Paga::getMoneda(){
    std::cout << "Devuelvo moneda: " << this->moneda << std::endl;
    return this->moneda;
}

void Paga::setMoneda(Moneda moneda){
    this->moneda = moneda;
}


float Paga::aDolar(float sueldoP){
    return sueldoP / cUSD;
    // if (this->moneda == 0)
    //     return sueldoP;
    // else        
    //     return sueldoP;
}   

float Paga::aPeso(float sueldoUS){
     return sueldoUS * cUSD;
 }
// ------ FIN ------------------------------ FUNCIONES PAGA --------------------------------
 