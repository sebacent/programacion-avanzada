#ifndef JORNALERO_H
#define JORNALERO_H
#include "Empleado.h"
#include <string>
//class Empleado;
class Empresa;
class Jornalero: public Empleado {
    
    private:
        int horas;

    public:
        Jornalero(std::string nombre, std::string ci, int edad, Paga valorHora, Empresa *miemp);
        ~Jornalero();
        void setHoras(int horas);
        int getHoras();
        float getSueldoPeso();
        float getSueldoDolar();

};

#endif