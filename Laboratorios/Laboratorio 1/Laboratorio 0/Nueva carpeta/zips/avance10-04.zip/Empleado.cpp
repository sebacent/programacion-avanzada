#include "Empleado.h"
#include <string>
#include <iostream>

using namespace std;
Empleado::Empleado(){};
Empleado::~Empleado(){};
void Empleado::setNombre(string nombre){
    this->nombre = nombre;
}
void Empleado::setCi(string ci){
    this->ci = ci;
}
void Empleado::setValorHora(Paga valorHora){
    this->valorHora = valorHora;
}
void Empleado::setEdad(int edad){
    this->edad = edad;
}

string Empleado::getNombre(){
    return this->nombre;
}

string Empleado::getCi(){
    return this->ci;
}

Paga Empleado::getValorHora(){
    return this->valorHora;
}

int Empleado::getEdad(){
    return this->edad;
}

void Empleado::setEmpresa(Empresa * miemp){
    this->miemp=miemp;
}


Empleado::Empleado(string nombre, string ci, int edad, Paga valorHora, Empresa *miemp){
    this->nombre = nombre;
    this->ci = ci;
    this->edad = edad;
    this->valorHora = valorHora;
}
float Empleado::getSueldoPeso(){

}
float Empleado::getSueldoDolar(){
    
}

void Empleado::imprimirEmpleado(){
    string nombre = this->getNombre();
    string ci = this->getCi();
    int edad = this->getEdad();
    Paga valorHora = this->getValorHora();
    float sueldo =  valorHora.getMonto();
    
    cout << "---------------------------------- "<<endl;  
    cout << "INFORMACION DEL EMPLEADO: "<<endl;  

    cout << "Nombre: " <<nombre<<endl;
    cout << "CI: " <<ci<<endl;
    cout << "Edad: " <<edad<<endl;
    cout << "Valor Hora: " <<sueldo <<endl;
    cout << "Valor Peso: " << this->getSueldoPeso() << endl;
    cout << "Valor Dolar: " << this->getSueldoDolar() << endl;

    cout << "---------------------------------- "<<endl;  
}






// ------ FIN ------------------------------- FUNCIONES EMPLEADO --------------------------------
