#include <iostream>
#include <string>
#include "Empresa.h"
#include "Paga.h"
#include "Fijo.h"
#include "Jornalero.h"
#include "Empleado.h"
#include <cstdlib>
#include <cstring>


using namespace std;


int main() {

    static Empresa empresa;
    empresa = Empresa();
    int opcion = 0;
   
    do {
        std::cout << "Menu" << std::endl;
        std::cout << "1. Dar de alta una empresa" << std::endl;
        std::cout << "2. Agregar empleado a la empresa" << std::endl;
        std::cout << "3. Calcular total de sueldos en pesos" << std::endl;
        std::cout << "4. Calcular total de sueldos en dolares" << std::endl;
        std::cout << "5. Listar empleados de la empresa" << std::endl;
        std::cout << "6. Salir" << std::endl;
        std::cout << "Ingrese una opcion: ";
        std::cin >> opcion;
        switch (opcion) {
            case 1: {
                char nombre[50], nombre_legal[50];
                int rut;

                printf("Ingrese nombre de la empresa: ");
                scanf("%s", nombre);
                if (strlen(nombre) > 20){
                    printf("Nombre con formato incorrecto.\n");
                    break;    
                }
                printf("Ingrese nombre legal de la empresa: ");
                scanf("%s", nombre_legal);
                if (strlen(nombre_legal) > 20){
                    printf("Nombre Legal con formato incorrecto.\n");
                    break;    
                }
                printf("Ingrese RUT de la empresa: ");
                scanf("%d", &rut);

                if ( rut < 1 || rut > 99999999) {
                    printf("Formato de RUT incorrecto.\n");
                    break; 
                }

                empresa = Empresa(nombre, nombre_legal, rut);
                //empresa = Empresa();
                //PRECARGA que no anda porque se muere en el 2do new :)
                if(1==2){
                    Jornalero * jorna = new (std::nothrow) Jornalero("JORGE MARTINEZ","50151411",22,Paga(250.8,Moneda::US) ,75,&empresa);
                    jorna->imprimirEmpleado();
                    if(jorna != nullptr){
                        empresa.AddEmpleado(jorna);
                    empresa.listarEmpleados();    
                    }
                    Jornalero * jorna1 = new (std::nothrow) Jornalero("PEDRO PIRIZ","4015141",35,Paga(180.8,Moneda::US) ,50,&empresa);
                    
                    if(jorna1 != nullptr)  {
                         jorna1->imprimirEmpleado();
                        empresa.AddEmpleado(jorna1);
                    }
                    Jornalero * jorna2 = new (std::nothrow) Jornalero("MARTIN DIAZ","4587495",40,Paga(300.8,Moneda::US) ,60,&empresa);
                     
                    if(jorna2 != nullptr)    {
                        jorna2->imprimirEmpleado();
                        empresa.AddEmpleado(jorna2);
                    }
                    Fijo* fij = new (std::nothrow) Fijo("MARIO BROS","1111222",35,Paga(185.8,Moneda::US),&empresa);
                    Fijo* fij1 = new (std::nothrow) Fijo("LUIS ENRIQUE","2221114",29,Paga(162.8,Moneda::US),&empresa);
                    Fijo* fij2 = new (std::nothrow) Fijo("LUCAS VIATRI","6665554",38,Paga(200.8,Moneda::US),&empresa);
                    if(fij != nullptr)
                        empresa.AddEmpleado(fij);
                    if(fij1 != nullptr)    
                        empresa.AddEmpleado(fij1);
                    if(fij2 != nullptr)    
                        empresa.AddEmpleado(fij2);
                }    
                break;

            }
            case 2: {
                char nombre[50], ci[8];
                int edad, tipo, horas,moneda;
                double valorHora;

                printf("Ingrese nombre del empleado: ");
                scanf("%s", nombre);
                if (strlen(nombre) > 20){
                    printf("Formato de nombre incorrecto.\n");
                    break;    
                }

                printf("Ingrese CI del empleado: ");
                scanf("%s", ci);

                // Verificación de entrada
                if (strlen(ci) > 8 || strlen(ci) < 7) {
                    printf("El largo de la CI no es correcto.\n");
                    break;
                }

                // Verificación de entrada
                for (int i = 0; ci[i] != '\0'; i++) {
                    if (!isdigit(ci[i])) {
                        printf("Formato de CI incorrecto. La cedula debe contener solo digitos.\n");
                        break;
                    }
                }

                printf("Ingrese edad del empleado: ");
                scanf("%d", &edad);     
                if(edad < 18)
                    printf("Ingrese una edad valida\n");

                printf("Ingrese valor hora del empleado: ");
                scanf("%lf", &valorHora);
                
                // Verificación de entrada
                if (valorHora <= 0 ) {
                    printf("Valor de hora incorrecto, debe ser mayor a 0.\n");
                    break;
                }


                printf("Ingrese moneda de paga (0 = USD, 1 = US): ");
                scanf("%d", &moneda);

                // Verificación de entrada
                if (moneda != 0 && moneda != 1 ) {
                    printf("Entrada inválida.\n");
                    break;
                }
                Moneda empMoneda;

                if (moneda == 0)
                    empMoneda = Moneda::USD;
                else 
                    empMoneda = Moneda::USD;

                Paga empPaga = Paga(valorHora, empMoneda);

                printf("Ingrese tipo de empleado (1. Jornalero, 2. Fijo): ");
                scanf("%d", &tipo);

                if (tipo == 1) {
                    printf("Ingrese horas trabajadas del empleado: ");
                    scanf("%d", &horas);

                    Jornalero* empJorna = new (std::nothrow) Jornalero(nombre, ci, edad, Paga(valorHora,empMoneda), horas, &empresa);
                    if(empJorna != nullptr){
                        empJorna->imprimirEmpleado();
                        empresa.AddEmpleado(empJorna);                       
                    } else {
                         cout<<"No se pudo crear el nuevo empleado."<<endl;
                    }    
                } else if (tipo == 2) {
                    cout<<"ANTES LLAMAR NEW EMPLEADO"<<endl<<endl;
                    Fijo* empFijo = new (std::nothrow) Fijo(nombre, ci, edad, Paga(valorHora,empMoneda), &empresa);
                    if(empFijo != nullptr) {
                        empFijo->imprimirEmpleado();
                        empresa.AddEmpleado(empFijo);                       
                    } else {
                         cout<<"No se pudo crear el nuevo empleado."<<endl;

                    }
                } else {
                    printf("Tipo de empleado no válido.\n");
                    return 0;
                }
                break;
            }
            case 3: {
                Paga totalSueldoPeso = empresa.totalSueldoPeso();
                std::cout << "Total de sueldos en pesos: " << totalSueldoPeso.getMonto() << std::endl;
                break;
            }
            case 4: {
                Paga totalSueldoDolar = empresa.totalSueldoDolar();
                std::cout << "Total de sueldos en dolares: " << totalSueldoDolar.getMonto() << std::endl;
                break;
            }
            case 5: {
               // empresa.empresaImprimir();
                empresa.listarEmpleados();
                break;
            }
            case 6:
                return 0;
            default:
                std::cout << "Opcion invalida." << std::endl;
                break;
        }
    } while (opcion != 6);

    //  Empresa pruebaEmpresa = Empresa();
    // pruebaEmpresa.empresaImprimir();
    
    // Jornalero * jorna = new Jornalero("FASFSA MARTINEZ","50151411",22,Paga(350.8,Moneda::US) ,50,&pruebaEmpresa);
    // jorna->imprimirEmpleado();
    // pruebaEmpresa.AddEmpleado(jorna);
    // pruebaEmpresa.listarEmpleados();
    
    // Fijo* fij = new (std::nothrow) Fijo("JORGE MARTINEZ","50151411",22,Paga(185.8,Moneda::US),&pruebaEmpresa);
    // cout<<"LLEGO ACAAA"<<endl;
    // if (fij != nullptr) {
    //     fij->imprimirEmpleado();
    //     pruebaEmpresa.AddEmpleado(fij);
    
    // } else {
    //     cout << "FIJO :: NO TENGO MEMORIAAA: "<<endl;

    // }
    

    // Jornalero * jorna2 = new (std::nothrow) Jornalero("PEDRO MARTINEZ","1515151",24,Paga(350.8,Moneda::US) ,55,&pruebaEmpresa);
    // if (jorna2 != nullptr) {
    //     jorna2->imprimirEmpleado();
    //     pruebaEmpresa.AddEmpleado(jorna2);
    
    // } else {
    //     cout << "NO TENGO MEMORIAAA: "<<endl;

    // }
    
    // Jornalero * jorna3 = new (std::nothrow) Jornalero("LUCAS MARTINEZ","1515151",24,Paga(350.8,Moneda::US) ,55,&pruebaEmpresa);
    // if (jorna3 != nullptr) {
    //     jorna3->imprimirEmpleado();
    //     pruebaEmpresa.AddEmpleado(jorna3);
    
    // } else {
    //     cout << "NO TENGO MEMORIAAA: "<<endl;

    // }
    // pruebaEmpresa.listarEmpleados();
    // cout << "FIJO:: GETSUELDOPESOS"<<fij->getSueldoPeso()<<endl;

    return 0;
}
//INICIO PRECARGA
    /*
    Empresa pruebaEmpresa = Empresa();
    pruebaEmpresa.empresaImprimir();
    
    Jornalero * jorna = new Jornalero("JORGE MARTINEZ","50151411",22,Paga(350.8,Moneda::US) ,50,&pruebaEmpresa);
    jorna->imprimirEmpleado();
    pruebaEmpresa.AddEmpleado(jorna);
    pruebaEmpresa.listarEmpleados();
    
    Fijo* fij = new (std::nothrow) Fijo("JORGE MARTINEZ","50151411",22,Paga(185.8,Moneda::US),&pruebaEmpresa);
    cout<<"LLEGO ACAAA"<<endl;
    if (fij != nullptr) {
        fij->imprimirEmpleado();
        pruebaEmpresa.AddEmpleado(fij);
    
    } else {
        cout << "FIJO :: NO TENGO MEMORIAAA: "<<endl;

    }
    

    Jornalero * jorna2 = new (std::nothrow) Jornalero("PEDRO MARTINEZ","1515151",24,Paga(350.8,Moneda::US) ,55,&pruebaEmpresa);
    if (jorna2 != nullptr) {
        jorna2->imprimirEmpleado();
        pruebaEmpresa.AddEmpleado(jorna2);
    
    } else {
        cout << "NO TENGO MEMORIAAA: "<<endl;

    }
    pruebaEmpresa.listarEmpleados();
    cout << "FIJO:: GETSUELDOPESOS"<<fij->getSueldoPeso()<<endl;
    */
    //FIN PRECARGA