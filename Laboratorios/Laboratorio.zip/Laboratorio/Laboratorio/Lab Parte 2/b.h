#ifndef B_H
#define B_H

class A;   // Declaracion forward de la clase A
class C;   // Declaracion forward de la clase C

class B{
    private:
        int b;
        A * miA;
        B * miB;
    public:
        B(int);
        void imprimir();
};

#endif // B_H
