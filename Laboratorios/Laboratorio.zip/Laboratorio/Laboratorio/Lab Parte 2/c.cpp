#include "c.h"
#include <iostream>
using namespace std;

C::C(int _c){
    c = _c;
}

void C::imprimir(){
    cout << "Clase: C c=" << c << endl;
}
