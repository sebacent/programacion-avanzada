#include <iostream>
#include "a.h"
#include "b.h"
#include "c.h"

using namespace std;

int main(){
    A a1(10);
    a1.imprimir();
    B b1(20);
    b1.imprimir();
    C c1(30);
    c1.imprimir();
    return 0;
}
