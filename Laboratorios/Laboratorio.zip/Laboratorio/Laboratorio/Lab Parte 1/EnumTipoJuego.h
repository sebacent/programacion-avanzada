#ifndef ENUM_TIPO_JUEGO
#define ENUM_TIPO_JUEGO

using namespace std;
enum TipoJuego{ 
	Accion,
	Aventura,
	Deporte,
	Otro
};
#endif
