#ifndef DT_PARTIDA_MULTIJUGADOR_H
#define DT_PARTIDA_MULTIJUGADOR_H
#define MAX_JUGADORES 5
#include "Jugador.h"
#include "DtPartida.h"
#include "DtFechaHora.h"
#include <iostream>

class DtPartidaMultijugador  : public DtPartida{
	private:
		bool transmitidaEnVivo;
		string * jugadores;
		int cantJugadores;
	public:
		DtPartidaMultijugador();
		DtPartidaMultijugador(bool,string*,int,DtFechaHora *,float,DtJugador *);
		//getters
		bool getTransmitidaEnVivo();
		string * getJugadores();
		int getCantJugadores();
		//setters
		void setTransmitidaEnVivo(bool transmitidaEnVivo);
		void setJugadores(string*);
		void setCantJugadores(int);
		void setDtJugador(DtJugador*);
		//destructor
		//metodos
		//sobrecarga
        void imprimir(ostream&);
		
};

#endif
