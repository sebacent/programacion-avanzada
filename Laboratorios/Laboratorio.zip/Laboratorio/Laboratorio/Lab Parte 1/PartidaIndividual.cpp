#include "PartidaIndividual.h"

//CONSTRUCTORES
PartidaIndividual::PartidaIndividual() : Partida(){

};


PartidaIndividual::PartidaIndividual(DtFechaHora * _hora, float _duracion, bool _continuaPartidaAnterior,Jugador * jugador) : Partida( _hora, _duracion,jugador){
	this->continuaPartidaAnterior = _continuaPartidaAnterior;
}


PartidaIndividual::PartidaIndividual(PartidaIndividual *) : Partida(){

};

// DESTRUCTOR
PartidaIndividual::~PartidaIndividual(){
};


//SETTERS
void PartidaIndividual::setcontinuaPartidaAnterior(bool _continuaPartidaAnterior){
	this->continuaPartidaAnterior = _continuaPartidaAnterior;
};

//GETERS
bool PartidaIndividual::getcontinuarPartidaAnterior(){
	return this->continuaPartidaAnterior;
};

//metodos
float PartidaIndividual::darTotalHorasParticipantes(){
	return this->getDuracion();
}


