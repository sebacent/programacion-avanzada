#include "Jugador.h"

// CONSTRUCTORES
Jugador::Jugador(){
    this->nickname = "";
    this->edad = 0;
    this->contrasenia = "";
};

Jugador::Jugador(string _nickname, int _edad, string _contrasenia){
    this->nickname = _nickname;
    this->edad = _edad;
    this->contrasenia = _contrasenia;
};

Jugador::Jugador(Jugador * J){
    this->nickname = "";
    this->edad = 0;
    this->contrasenia ="";
};

// DESTRUCTOR
Jugador::~Jugador(){
};

// SETTERS
void Jugador::setnickname(string _nickname){
    this->nickname = _nickname;
};

void Jugador::setedad(int _edad){
    this->edad = _edad;
};

void Jugador::setcontrasenia(string _contrasenia){
    this->contrasenia = _contrasenia;
};

//GETTERS

string Jugador::getnickname(){
    return this->nickname;
};

int Jugador::getedad(){
    return this->edad;
};

string Jugador::getcontrasenia(){
    return this->contrasenia;
};


DtJugador * Jugador::devolverDt(){
	DtJugador * res = new DtJugador(this->getnickname(),this->getedad());
	return res;
}
































