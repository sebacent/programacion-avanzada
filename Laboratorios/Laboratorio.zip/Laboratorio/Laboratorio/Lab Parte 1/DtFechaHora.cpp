#include "DtFechaHora.h"

DtFechaHora::DtFechaHora(){
    time_t t;
    struct tm *tm;
    t=time(NULL);
    tm=localtime(&t);
    this->dia = tm->tm_mday;
    this->mes = tm->tm_mon + 1;
    this->anio = 1900+tm->tm_year;
    this->hora = tm->tm_hour;
    this->minuto = tm->tm_min;
};

DtFechaHora::DtFechaHora(int _dia, int _mes,int _anio,int _hora, int _minuto){
    this->dia = _dia;
	this->mes = _mes;
	this->anio = _anio;
	this->hora = _hora;
	this->minuto = _minuto;
};

int DtFechaHora::getDia(){
    return this->dia;
}

int DtFechaHora::getMes(){
    return this->mes;
}

int DtFechaHora::getAnio(){
    return this->anio;
}

int DtFechaHora::getHora(){
    return this->hora;
}

int DtFechaHora::getMinuto(){
    return this->minuto;
}

