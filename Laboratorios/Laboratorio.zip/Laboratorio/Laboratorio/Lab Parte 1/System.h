#ifndef SYSTEM_H
#define SYSTEM_H
#define MAX_JUGADORES 5
#define MAX_VIDEOJUEGOS 5
#include "Partida.h"
#include "Videojuego.h"
#include "Jugador.h"
#include "EnumTipoJuego.h"
#include <iostream>
#include "DtPartida.h"
#include "DtJugador.h"
#include "DtPartidaIndividual.h"
#include "DtPartidaMultijugador.h"
#include <stdexcept>
#include <typeinfo>

using namespace std;

class System{
	private:
		VideoJuego ** mis_videojuegos;
        unsigned cantVideojuegos;
        Jugador ** mis_jugadores;
        unsigned cantJugadores;
        
    public:
    	System();
    	//falta hacer
    	//void iniciarPartida(string,string,DtPartida *);
    	//DtPartida** obtenerPartidas(string videojuego, int& cantPartidas);
    	void agregarVideoJuego(string,TipoJuego);
    	void agregarJugador(string,int,string);
    	DtJugador** obtenerJugadores(int& cantJugadores);
    	DtVideoJuego ** obtenerVideoJuegos(int& cantVideojuegos);
    	void iniciarPartida(string,string,DtPartida *);
    	DtPartida** obtenerPartidas(string videojuego, int& cantPartidas);
    	// FUNCIONES AUXILIARES
    	Jugador **obtenerJugadoresDesdeNick(string *,int);
    	bool estaEnArray(int*,int,int);//el primer parametro es un arreglo de ints(las opciones que selecciono el usuario),
									   //el segundo es la cantidad de opciones que selecciono y el tercero es el numero que queres saber si esta en el array o no jejeeeeeeeee		
    	
    	int getCantVideoJuegos();
    	int getCantJugadores();
    	int& getCantVideoJuegosA();
    	int& getCantJugadoresA();
};
#endif
