#include "DtPartidaIndividual.h"
DtPartidaIndividual::DtPartidaIndividual(){
	
}
DtPartidaIndividual::DtPartidaIndividual(bool continuarPartidaAnterior,DtFechaHora * fecha,float duracion,DtJugador* j):DtPartida (fecha, j,duracion){
	this->continuarPartidaAnterior=continuarPartidaAnterior;
}

bool DtPartidaIndividual::getContinuarPartidaAnterior(){
	return this->continuarPartidaAnterior;
}

//sobrecarga
void DtPartidaIndividual::imprimir(ostream&){
	
    cout << "##DATOS DE LA PARTIDA##"<<endl<<endl;
    cout << "Tipo: Individual"<<endl;
    DtFechaHora* f = getFecha();
    cout << "Fecha:"<<f->getAnio()<<"/"<<f->getMes()<<"/"<<f->getDia()<<"-"<<f->getHora()<<":"<<f->getMinuto()<<endl;
    cout << "Duracion:"<<getDuracion()<<endl;
    cout << "Continuacion de una partida anterior:";
        if(getContinuarPartidaAnterior())
        cout << "SI";
        else
            cout << "NO";
        cout<<endl;

    cout << "Partida iniciada por:"<<getDtJugador()->getNickname()<<endl;
    cout<< "-----------------------------------------------------------------------------------------------------------"<< "\n" << endl;
}
