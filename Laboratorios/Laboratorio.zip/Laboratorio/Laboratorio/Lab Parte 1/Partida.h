#ifndef PARTIDA_H
#define PARTIDA_H
#include "DtFechaHora.h"
#include "DtPartida.h"
#include "Jugador.h"
using namespace std;

class Partida{

        private:
            //atributos
            DtFechaHora * fecha;
            float duracion;
            Jugador * iniciador;
        public:
            //constructores
            Partida();
            Partida(DtFechaHora *,float,Jugador *);
            Partida(Partida*);
            //destructor
            ~Partida();
            //getters
            DtFechaHora * getFecha();
            float getDuracion();
            Jugador * getIniciador();
            //setters
            void setFecha(DtFechaHora*);
            void setDuracion(float);
            void setIniciador(Jugador *);
			
            //metodos
            virtual float darTotalHorasParticipantes() = 0;
};

#endif
