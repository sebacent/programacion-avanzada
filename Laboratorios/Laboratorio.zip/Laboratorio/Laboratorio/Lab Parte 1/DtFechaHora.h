#ifndef DT_FECHAHORA_H
#define DT_FECHAHORA_H
#include <iostream>
#include "string"
#include <time.h>

using namespace std;

class DtFechaHora{
	private:
		int dia;
		int mes;
		int anio;
		int hora;
		int minuto;
	public:
	// CONSTRUCTORES
		DtFechaHora();
		DtFechaHora(int, int, int, int, int);
	// GETTERS
		int getDia();
		int getMes();
		int getAnio();
		int getHora();
		int getMinuto();
	//metodo
};


#endif
