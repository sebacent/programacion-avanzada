#include "Videojuego.h"

//Constructores
VideoJuego::VideoJuego(){
	this->nombre = "Vacio";
	this->genero = Otro;
	this->mis_partidas = new Partida * [MAX_PARTIDAS];
    this->cantPartidas = 0;
};

VideoJuego::VideoJuego(string _nombre,TipoJuego _genero){
	this->nombre = _nombre;
	this->genero = _genero;
	this->mis_partidas = new Partida * [MAX_PARTIDAS];
    this->cantPartidas = 0;
};

//VideoJuego::VideoJuego(VideoJuego * v){
//	this->nombre = v->getNombre();
//	this->genero = v->getGenero();
//};

// Destructores
VideoJuego::~VideoJuego(){
};

//Setters
void VideoJuego::setNombre(string _nombre){
	this->nombre = _nombre;
};

void VideoJuego::setGenero(TipoJuego _genero){
	this->genero = _genero;
};

//Getters
string VideoJuego::getNombre(){
	return this->nombre;
};

TipoJuego VideoJuego::getGenero(){
	return this->genero;
};
	
DtVideoJuego* VideoJuego::devolverDt(){
//	Tipo tipoJuego = "";
//	
//	if(this->genero = Accion){
//		tipoJuego ="Accion";
//	}else if(this->genero = Aventura){
//			tipoJuego ="Aventura";
//	}else if(this->genero = Deporte){
//			tipoJuego ="Deporte";
//	}else {
//			tipoJuego ="Otro";
//	}
	
	float sumaHoras = 0;
	
	for(int i =0;i < this->cantPartidas;i++){
		sumaHoras = sumaHoras+ mis_partidas[i]->darTotalHorasParticipantes();
	}
	DtVideoJuego * res = new DtVideoJuego(this->nombre,this->genero,sumaHoras);
	return res;
}

int VideoJuego::getCantPartidas(){
	return this->cantPartidas;
}

DtPartida ** VideoJuego::getDtPartidas(){
	DtPartida ** pres;
	if(this->cantPartidas != 0){
		pres = new DtPartida*[this->cantPartidas];
		DtPartida * p2;
		DtPartida * p1;
		for (int i = 0; i < this->cantPartidas; i++){
			PartidaMultijugador * pm = dynamic_cast<PartidaMultijugador*>(this->mis_partidas[i]);
			if(pm){
				p1 = new DtPartidaMultijugador(pm->gettransmitidaEnVivo(),pm->getNickJugadores(),pm->darCantJugadores(),pm->getFecha(),pm->getDuracion(),pm->getIniciador()->devolverDt());
				pres[i] = p1;
			}else{
				PartidaIndividual * pi = dynamic_cast<PartidaIndividual*>(this->mis_partidas[i]);
				p2 = new DtPartidaIndividual(pi->getcontinuarPartidaAnterior(),pi->getFecha(),pi->getDuracion(),pi->getIniciador()->devolverDt());
				pres[i] = p2;
			}	
		}
	}else{
		return NULL;
	}
	return pres;
}

bool VideoJuego::agregarPartida(Partida * partida){
	if(cantPartidas < MAX_PARTIDAS){
		this->mis_partidas[cantPartidas] = partida;
		this->cantPartidas++;
		return true;
	}else{
		return false;
	}
}

