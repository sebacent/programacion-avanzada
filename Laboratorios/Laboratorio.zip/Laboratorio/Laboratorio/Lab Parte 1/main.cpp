#include "Partida.h"
#include "Videojuego.h"
#include "EnumTipoJuego.h"
#include "DtPartida.h"
#include "DtJugador.h"
#include "DtFechaHora.h"
#include "PartidaIndividual.h"
#include "PartidaMultijugador.h"
#include "DtPartidaIndividual.h"
#include "DtPartidaMultijugador.h"
#include "Jugador.h"
#include "System.h"
#include <conio.h>
#include <cctype>
using namespace std;

int main(){
	
	System * sis = new System();
	DtFechaHora * fh = new DtFechaHora();
	string * arr = new string[1];
	DtJugador* dt = new DtJugador();
//	DtPartidaMultijugador * pm = new DtPartidaMultijugador(false,arr, 1,fh, 1.2,dt);
//	DtPartidaIndividual * pi = new DtPartidaIndividual(false,fh,1.2,dt);
//	sis->agregarJugador("j",4,"123");
//	sis->iniciarPartida("","",pm);
	
	int opc;
	do{
		system("cls");
		cout << "<< BIENVENIDOS AL SISTEMA >>" << endl;
        cout << "ELIJA OPCIONES DEL MENU:" << endl;
        cout << "   1. Agregar Jugador " << endl;
        cout << "   2. Agregar VideoJuego " << endl;
        cout << "   3. Obtener Jugadores " << endl;
        cout << "   4. Obtener VideoJuego" << endl;
        cout << "   5. Obtener Partida" << endl;
        cout << "   6. Iniciar Partida" << endl;
        cout << "   0. Salir" << endl;
		
		cout << "Inserte una opcion" << endl;
		cout << "------> ";
		cin >> opc;
		
		
		
		switch (opc){
		case 1:{
			
			int opci;
			
			do{
			system("cls");
			string _nickname, _contrasenia;
			int _edad;
			cout << " INICILIZANDO CREACION DE JUGADOR " << "\n" << endl;
			cout << " Ingrese nickname del Jugador "  << endl;
			cout << "------> ";
			cin >> _nickname;
			cout << " Ingrese la edad del Jugador " << endl;
			cout << "------> ";
			cin >> _edad;
			cout << " Ingrese la contrase�a del Jugador " << endl;
			cout << "------> ";
			cin >> _contrasenia;
			system("cls");
			try{
				sis ->agregarJugador(_nickname ,_edad, _contrasenia);
			}catch (const std::invalid_argument& ia) {
	  			std::cerr << "Invalid argument: " << ia.what() << '\n';
  			}
			
			
			cout << " Desea ingresar otro Jugador? " << endl;
			cout << " 1. SI " << endl;
			cout << " 2. NO " << endl;
			cout << "------> ";
			cin >> opci;
		    }
			while(opci==1);
			cout << " Aprete una tecla para continuar" << endl;
			getch();
		    break;
		}
		case 2:{
			int opci;
			
			do{
			system("cls");
			string nombre;
			int genero;
			cout << " INICILIZANDO CREACION DE VIDEOJUEGO " << "\n" << endl;
			cout << " Ingrese nombre del VideoJuego "  << endl;
			cout << "------> ";
			cin >> nombre;
					cout << " Seleccione el genero de su videojuego " << "\n" << endl;
					cout << " 1. Accion "  << endl;
					cout << " 2. Aventura "  << endl;
					cout << " 3. Deporte "  << endl;
					cout << " 4. Otro "  << endl;
					cout << "------> ";
					cin >> genero;
					switch(genero){
						case 1:{
							try{
								sis->agregarVideoJuego(nombre, Accion);
								cout << "Videojuego agregado correctamente" << "\n" << endl;
							}catch (const std::invalid_argument& ia) {
	  							std::cerr << "Invalid argument: " << ia.what() << '\n';
  							}
							break;
					    }
						case 2:{
							try{
						        sis->agregarVideoJuego(nombre, Aventura);
						        cout << "Videojuego agregado correctamente" << "\n" << endl;
					        }catch (const std::invalid_argument& ia) {
	  							std::cerr << "Invalid argument: " << ia.what() << '\n';
  							}
					        break;
						}	
						case 3:{
							try{
							    sis->agregarVideoJuego(nombre , Deporte);
							    cout << "Videojuego agregado correctamente" << "\n" << endl;
						    }catch (const std::invalid_argument& ia) {
	  							std::cerr << "Invalid argument: " << ia.what() << '\n';
  							}
						    break;
						}		
						case 4:{
							try{
								sis->agregarVideoJuego(nombre , Otro);
								cout << "Videojuego agregado correctamente" << "\n" << endl;
							}catch (const std::invalid_argument& ia) {
	  							std::cerr << "Invalid argument: " << ia.what() << '\n';
  							}
							break;
							}			
						default:
							cout << "Numero de Genero Ingresado Incorrecto" << "\n" << endl;
							break;
					}
					
			//system("cls");
			cout << " Desea ingresar otro VideoJuego? " << endl;
			cout << " 1. SI " << endl;
			cout << " 2. NO " << endl;
			cout << "------> ";
			cin >> opci;
		    }
			while(opci==1);
			cout << " Aprete una tecla para continuar" << endl;
			getch();
			break;
		}
		
		case 3:{
			if (sis->getCantJugadores() != 0){
				system("cls");
				cout << " Listado de Jugadores " << "\n" << endl;
				DtJugador ** arrDtJugador = sis->obtenerJugadores(sis->getCantJugadoresA());
				int cantJugadores = sis->getCantJugadores();
				for(int i = 0; i<cantJugadores;i++){
				
					cout<< "Jugador nro:"<< i+1 << endl;
					cout<< "El Nickname del jugador es " << arrDtJugador[i]->getNickname() << endl;
					cout<< "La Edad del jugador es " << arrDtJugador[i]->getEdad() << endl;
					cout<< "-----------------------------------------------------------------------------------------------------------"<< "\n" << endl;
				}	
			}else {
				cout << "No hay jugadores agregados en el sistema" << endl;
			}
			cout << " Aprete una tecla para continuar" << endl;
			getch();
			break;
		}
		case 4:{
			if(sis->getCantVideoJuegos() != 0){
						system("cls");
			cout << " Listado de VideoJuegos " << "\n" << endl;
			DtVideoJuego ** arrDtVideoJuego = sis->obtenerVideoJuegos(sis->getCantVideoJuegosA());
			int cantVideojuegos = sis->getCantVideoJuegos();
			for(int i = 0; i<cantVideojuegos;i++){
				cout<< "VideoJuego nro:"<< i+1 << endl;
				cout<< "El Titulo del VideoJuego es " << arrDtVideoJuego[i]->getTitulo()<< endl;
				if (arrDtVideoJuego[i]->getGenero()==0){
					cout<< "El Genero del VideoJuego es Accion"<< endl;
				}else if(arrDtVideoJuego[i]->getGenero()==1){
					cout<< "El Genero del VideoJuego es Aventura"<< endl;
				}else if(arrDtVideoJuego[i]->getGenero()==2){
					cout<< "El Genero del VideoJuego es Deporte"<< endl;
				}else if(arrDtVideoJuego[i]->getGenero()==3){
					cout<< "El Genero del VideoJuego es Otro"<< endl;
				}
				cout<< "-----------------------------------------------------------------------------------------------------------"<< endl;
			}	
			}else{
				cout << "No hay videojuegos agregados en el sistema" << endl;
			}
			cout << " Aprete una tecla para continuar" << endl;
			getch();
			break;	
		}
		case 5:{
			if (sis->getCantVideoJuegos() != 0){
				int opcionVideoJuego;
			system("cls");
			DtVideoJuego ** arrDtVideoJuego = sis->obtenerVideoJuegos(sis->getCantVideoJuegosA());
			cout << " Listado de Partidas "<< endl;
			do{
				cout << " Listado de VideoJuegos " << "\n" << endl;
				int cantVideojuegos = sis->getCantVideoJuegos();
					for(int i = 0; i<cantVideojuegos;i++){
					cout<< "VideoJuego nro:"<< i+1 << endl;
					cout<< "El Titulo del VideoJuego es " << arrDtVideoJuego[i]->getTitulo() << endl;
					if (arrDtVideoJuego[i]->getGenero()==1){
						cout<< "El Genero del VideoJuego es Accion"<< endl;
					}else if(arrDtVideoJuego[i]->getGenero()==2){
						cout<< "El Genero del VideoJuego es Aventura"<< endl;
					}else if(arrDtVideoJuego[i]->getGenero()==3){
						cout<< "El Genero del VideoJuego es Deporte"<< endl;
					}else if(arrDtVideoJuego[i]->getGenero()==4){
						cout<< "El Genero del VideoJuego es Otro"<< endl;
					}
				}
				cout << " Ingrese numero videojuego que desea listar sus partidas: " << endl;
				cout << "------> ";
				cin >> opcionVideoJuego;
				if(opcionVideoJuego < 1 || opcionVideoJuego > sis->getCantVideoJuegos()){
					cout << "Opcion incorrecta , seleccione un numero valido de videoJuego" << endl;
				}
			}while(opcionVideoJuego < 1 || opcionVideoJuego > sis->getCantVideoJuegos());
			int cantPartidas;
			try{
				DtPartida ** partidas = sis->obtenerPartidas(arrDtVideoJuego[opcionVideoJuego-1]->getTitulo(),cantPartidas);
				for(int i = 0; i < cantPartidas;i++){
					cout<<partidas[i]<<endl;
				}
			}catch(const std::invalid_argument& ia){
				std::cerr << "Invalid argument: " << ia.what() << '\n';
			}
			
			}else{
				cout << "No hay videojuegos agregados en el sistema" << endl;
			}
		cout << " Aprete una tecla para continuar" << endl;
		getch();	
		break;
		}
		case 6:{
			if(sis->getCantVideoJuegos() != 0 && sis->getCantJugadores() != 0 ){
			bool validoNombreini = false;
			bool videoJvalido = false; 
			int tipoP, nombreIni;
			string opcionVideoJuego;
			system("cls");
			DtFechaHora * fecha = new DtFechaHora();
			DtJugador ** arrDtJugador = sis->obtenerJugadores(sis->getCantJugadoresA());
			DtVideoJuego ** arrDtVideoJuego = sis->obtenerVideoJuegos(sis->getCantVideoJuegosA());
			do{
			cout << " Iniciar Partida " << "\n" << endl;
			cout << " Seleccione jugador que inicia la partida" << endl;
			cout << " Listado de Jugadores " << "\n" << endl;
			int cantJugadores = sis->getCantJugadores();
			for(int i = 0; i<cantJugadores;i++){
				cout<< "Jugador nro:"<< i+1 << endl;
				cout<< "El Nickname del jugador es " << arrDtJugador[i]->getNickname() << endl;
				cout<< "La Edad del jugador es " << arrDtJugador[i]->getEdad() << endl;
				cout<< "-----------------------------------------------------------------------------------------------------------"<< "\n" << endl;
			}
			cout << "------> ";
			cin >> nombreIni;
			nombreIni = nombreIni-1;
			if(nombreIni >= 0 && nombreIni < sis->getCantJugadores()){
				validoNombreini = true;
			}else{
				cout<< "Ingreso un numero invalido de jugador" << endl;
			}
			}while(validoNombreini == false);
			
			do{
				cout << " Listado de VideoJuegos " << "\n" << endl;
				int cantVideojuegos = sis->getCantVideoJuegos();
					for(int i = 0; i<cantVideojuegos;i++){
					cout<< "VideoJuego nro:"<< i+1 << endl;
					cout<< "El Titulo del VideoJuego es " << arrDtVideoJuego[i]->getTitulo()<< endl;
					if (arrDtVideoJuego[i]->getGenero()==1){
						cout<< "El Genero del VideoJuego es Accion"<< endl;
					}else if(arrDtVideoJuego[i]->getGenero()==2){
						cout<< "El Genero del VideoJuego es Aventura"<< endl;
					}else if(arrDtVideoJuego[i]->getGenero()==3){
						cout<< "El Genero del VideoJuego es Deporte"<< endl;
					}else if(arrDtVideoJuego[i]->getGenero()==4){
						cout<< "El Genero del VideoJuego es Otro"<< endl;
					}
				}
				cout << " Ingrese nombre del videjuego a iniciar partida" << endl;
				cout << "------> ";
				cin >> opcionVideoJuego;
				for(int i = 0; i<cantVideojuegos;i++){
					if(opcionVideoJuego == arrDtVideoJuego[i]->getTitulo()){
						videoJvalido = true;
					}
					else
						cout << "Opcion incorrecta , seleccione un nombre valido de videoJuego" << endl;
				}
			}while(videoJvalido == false);
			cout << " Ingrese Duracion de partida" << endl;
			cout << "------> ";
			float duracion;
			cin >> duracion;
			
			cout << " Seleccione el tipo de su partida " << "\n" << endl;
					cout << " 1. Individual "  << endl;
					cout << " 2. MultiJugador "  << endl;
			cout << "------> ";
			cin >> tipoP;
			
			switch(tipoP){
				case 1:{
					cout << " Desea continuar una partida anterior o crear una nueva " << "\n" << endl;
					cout << " 1. Continuar partida Anterior "  << endl;
					cout << " 2. Crear una partida Nueva "  << endl;
					int opci;
					cout << "------> ";
					cin >> opci;
					bool pa;
					switch(opci){
						case 1:{
							try{
								DtPartidaIndividual * Individual = new DtPartidaIndividual(pa=true,fecha, duracion, arrDtJugador[nombreIni]);
								sis->iniciarPartida( arrDtJugador[nombreIni]->getNickname(), opcionVideoJuego , Individual);
							}catch(const std::invalid_argument& ia){
								std::cerr << "Invalid argument: " << ia.what() << '\n';
							}
							break;
						}
						case 2:{
							try{
								DtPartidaIndividual * Individual = new DtPartidaIndividual(pa=false,fecha, duracion, arrDtJugador[nombreIni]);
								sis->iniciarPartida( arrDtJugador[nombreIni]->getNickname(), opcionVideoJuego , Individual);
							}catch(const std::invalid_argument& ia){
								std::cerr << "Invalid argument: " << ia.what() << '\n';
							}
							break;
						}
						default:
							cout << "opcion no valida"  << endl;
							break;
					}
					
				break;	
	
				}
				case 2:{
					//verificacion para seleccionar jugadores
					DtJugador** jugadores = sis->obtenerJugadores(sis->getCantJugadoresA());
					int arr[MAX_JUGADORES];//aca estan los indices de los jugadores selecionados
					int cantJugadoresAgregados=1;
					int opcion;
					bool opcib= true;
					int opci;
					bool enVivo;
					int opcv;
					
					do{
						cout<<"Seleccione el jugador que desea aniadir a la partida"<<endl;
						for(int i =0;i < sis->getCantJugadores();i++){
							if(!sis->estaEnArray(arr,cantJugadoresAgregados,i) && i != nombreIni){
								//muestra la info del jugador
								cout<< "Jugador nro:"<< i+1 << endl;
								cout<< "El Nickname del jugador es " << arrDtJugador[i]->getNickname() << endl;
								cout<< "La Edad del jugador es " << arrDtJugador[i]->getEdad() << endl;
								cout<< "-----------------------------------------------------------------------------------------------------------"<< "\n" << endl;
							}
						}
						cin >> opcion;
						//pide el numero y lo guardo en int opcion
						
							if(!sis->estaEnArray(arr,cantJugadoresAgregados,opcion-1)&& opcion-1 != nombreIni){
								if(opcion <= sis->getCantJugadores() && opcion >= 1){
									arr[cantJugadoresAgregados] = opcion-1;
									cantJugadoresAgregados++;
								}else{
									cout<<"Opcion incorrecta"<<endl;
								}
							}else{
								cout<<"Ya selecciono esa opcion"<<endl;
							}
							cout<<"Desea seguir aniadiendo jugadores a la partida"<<endl;
							cout<<"1.Si"<<endl;
							cout<<"2.No"<<endl;
							cout << "------> ";
							cin >> opci;
							switch (opci){
								case 1:{
									opcib=true;
									break;
								}
								case 2:{
									opcib=false;
									break;
								}
								default:{
									break;
								}
							}	
					}while(opcib == true && cantJugadoresAgregados < sis->getCantJugadores());
					if(cantJugadoresAgregados == sis->getCantJugadores()){
						cout<<"Ya agregaste todos los jugadores del sistema a esta partida !"<<endl;
					}
					string nombresJugadoresAgregados[cantJugadoresAgregados];
			        for(int i = 0;i<cantJugadoresAgregados;i++){
			            for(int j = 0;i<sis->getCantJugadores();i++){
			                if(arr[i] == j){
			                    nombresJugadoresAgregados[i] = jugadores[j]->getNickname();
			                }
			            }
			        }
					do{
						cout<<"La partida es trasmitida en vivo "<<endl;
						cout<<"1.Si"<<endl;
						cout<<"2.No"<<endl;
						cout << "------> ";
						cin>>opcv;
						switch (opcv){
							case 1:{
								try{
									DtFechaHora * fecha = new DtFechaHora();
									DtPartidaMultijugador * MultiJugador = new DtPartidaMultijugador(enVivo=true,nombresJugadoresAgregados, cantJugadoresAgregados,fecha,duracion,arrDtJugador[nombreIni]);
									sis->iniciarPartida(arrDtJugador[nombreIni]->getNickname(), opcionVideoJuego, MultiJugador);
									cout << "Partida Agregada Correctamente" << endl;
								}catch(const std::invalid_argument& ia){
									std::cerr << "Invalid argument: " << ia.what() << '\n';
								}
								break;
							}
							case 2:{
								try{
									DtFechaHora * fecha = new DtFechaHora();
									DtPartidaMultijugador * MultiJugador = new DtPartidaMultijugador(enVivo=false,nombresJugadoresAgregados, cantJugadoresAgregados,fecha,duracion,arrDtJugador[nombreIni]);
									sis->iniciarPartida(arrDtJugador[nombreIni]->getNickname(), opcionVideoJuego, MultiJugador);
									cout << "Partida Agregada Correctamente" << endl;
								}catch(const std::invalid_argument& ia){
									std::cerr << "Invalid argument: " << ia.what() << '\n';
								}
								break;
							}
							default:{
								cout<<"opcion incorrecta"<<endl;
								break;
							}
						}
					}while(opcv != 1 && opcv != 2);		
				break;
				}	
			}	
			}else {
				cout << "Tiene que existir por lo menos 1 videojuego y 1 jugador en el sistema" << endl;
			}
		cout << " Aprete una tecla para continuar" << endl;
		getch();
		break;	
		}
			
		}
	} while(opc!=0);
}


