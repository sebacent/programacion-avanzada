#ifndef JUGADOR_H
#define JUGADOR_H
#include <string>
#include "DtJugador.h"

using namespace std;

class Jugador{
    private:
        // ATRIBUTOS
        string nickname;
        int edad;
        string contrasenia;
    public:
        // CONSTRUCTORES
        Jugador();
        Jugador(string,int,string);
        Jugador(Jugador *);
        // DESTRUCTOR
        ~Jugador();
        // SETTERS
        void setnickname(string);
        void setedad(int);
        void setcontrasenia(string);
        // GETTERS
        string getnickname();
        int getedad();
        string getcontrasenia();
        //funciones
        DtJugador * devolverDt();
};
#endif
