#include "DtPartida.h"

//CONSTRUCTORES

DtPartida::DtPartida(){

    this->fecha = new DtFechaHora();
    this->duracion=0;
    this->jugador = NULL;
    
}

DtPartida::DtPartida(DtFechaHora * _fecha,DtJugador * jugador,float _duracion){

    this->fecha = _fecha;
    this->duracion= _duracion;
    this->jugador = jugador;
}

DtPartida::DtPartida(DtPartida* p){

    this->fecha=p->getFecha();
    this->duracion = p->getDuracion();
    this->jugador = p->getDtJugador();
}

DtJugador * DtPartida::getDtJugador(){
	return this->jugador;
}

DtPartida::~DtPartida(){
}

//GETTERS
DtFechaHora * DtPartida::getFecha(){
    return this->fecha;
}

float DtPartida::getDuracion(){
    return duracion;
}
//sobrecarga
ostream& operator<<(ostream& res, DtPartida* info){
    info->imprimir(res);
    return res;
}



