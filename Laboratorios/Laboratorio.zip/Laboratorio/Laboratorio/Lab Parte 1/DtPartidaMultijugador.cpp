#include "DtPartidaMultijugador.h"
DtPartidaMultijugador::DtPartidaMultijugador(){
	this->transmitidaEnVivo = false;
	this->jugadores = new string[MAX_JUGADORES];
}
DtPartidaMultijugador::DtPartidaMultijugador(bool transmitidaEnVivo,string * jugadores, int cantJugadores,DtFechaHora * fecha,float duracion,DtJugador * jugador):DtPartida (fecha,jugador, duracion){
	this->transmitidaEnVivo = transmitidaEnVivo;
	this->jugadores = new string[MAX_JUGADORES];
	this->jugadores = jugadores;
	this->cantJugadores = cantJugadores;
}
bool DtPartidaMultijugador::getTransmitidaEnVivo(){
	return this->transmitidaEnVivo;
}
string* DtPartidaMultijugador::getJugadores(){
	return this->jugadores;
}
void DtPartidaMultijugador::setTransmitidaEnVivo(bool transmitida){
	this->transmitidaEnVivo = transmitida;
}
void DtPartidaMultijugador::setJugadores(string* jugadores){
	this->jugadores = jugadores;
}

int DtPartidaMultijugador::getCantJugadores(){
		return this->cantJugadores;
	}
	
void DtPartidaMultijugador::setCantJugadores(int cantJugadores){
	this->cantJugadores = cantJugadores;
}

//sobrecarga
void DtPartidaMultijugador::imprimir(ostream&){

    cout << "##DATOS DE LA PARTIDA##"<<endl<<endl;

    cout << "Tipo: Multijugador"<<endl;
    DtFechaHora* f = getFecha();
    cout << "Fecha:"<<f->getAnio()<<"/"<<f->getMes()<<"/"<<f->getDia()<<"-"<<f->getHora()<<":"<<f->getMinuto()<<endl;
    cout << "Duracion:"<<getDuracion()<<endl;
        cout << "Transmitida en vivo:";
        if(getTransmitidaEnVivo())
        cout << "SI";
        else
            cout << "NO";
        cout<<endl;
    cout << "Cantidad de jugadores en simultaneo:"<<getCantJugadores()<<endl;
    string * j = getJugadores();
    string nombres = "";
    for(int i = 0;i<getCantJugadores();i++){
    	if(i==0){
    		nombres = j[i];
		}else{
			nombres = nombres+"-"+j[i];
		}
    	
	}
    cout << "Jugadores unidos:"<<nombres<<endl;
    cout << "Partida iniciada por:"<<getDtJugador()->getNickname();
    cout<< "-----------------------------------------------------------------------------------------------------------"<< "\n" << endl;

}

