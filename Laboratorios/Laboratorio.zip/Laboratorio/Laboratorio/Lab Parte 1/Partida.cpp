#include "Partida.h"

//CONSTRUCTORES

Partida::Partida(){
	this->iniciador	= NULL;
    this->fecha = new DtFechaHora();
    this->duracion=0;
}

Partida::Partida(DtFechaHora * _fecha,float _duracion,Jugador * ini){
	this->iniciador	= ini;
    this->fecha = _fecha;
    this->duracion= _duracion;
}

Partida::Partida(Partida* p){
	this->iniciador = p->getIniciador();
    this->fecha=p->getFecha();
    this->duracion = p->getDuracion();
}

//DESTRUCTOR
Partida::~Partida(){}

//GETTERS
DtFechaHora * Partida::getFecha(){
    return fecha;
}

float Partida::getDuracion(){
    return duracion;
}
Jugador * Partida::getIniciador(){
	return this->iniciador;
}
//SETTERS
void Partida::setFecha(DtFechaHora * x){
    this->fecha=x;
}

void Partida::setDuracion(float x){
    this->duracion=x;
}

void Partida::setIniciador(Jugador*jug){
	this->iniciador = jug;
}
//METODOS
float Partida::darTotalHorasParticipantes(){

    //falta implementar
}

