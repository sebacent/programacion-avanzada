#ifndef DT_PARTIDA
#define DT_PARTIDA
#include "DtFechaHora.h"
#include "DtJugador.h"

using namespace std;

class DtPartida{

        private:
            //atributos
            DtFechaHora * fecha;
            float duracion;
			DtJugador * jugador;
        public:
            //constructores
            DtPartida();
            DtPartida(DtFechaHora*,DtJugador*,float);
            DtPartida(DtPartida*);
            virtual ~DtPartida() = 0;
            //getters
            DtFechaHora * getFecha();
            float getDuracion();
            DtJugador * getDtJugador();
            //metodos 
            friend ostream& operator<<(ostream&,DtPartida*);
            virtual void imprimir(ostream&) = 0;
};

#endif
