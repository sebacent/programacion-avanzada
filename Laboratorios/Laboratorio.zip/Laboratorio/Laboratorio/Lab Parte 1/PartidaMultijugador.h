#ifndef PARTIDAMULTIJUGADOR_H
#define PARTIDAMULTIJUGADOR_H
#include <string>
#include "Partida.h"
#include "Jugador.h"
#include "DtJugador.h"
#include  "DtPartidaMultijugador.h"
#define MAX_JUGADORES 5

using namespace std;

class PartidaMultijugador : public Partida{
    private:
        // ATRIBUTOS
        bool transmitidaEnVivo;
        Jugador ** jugadores;
        int cantJugadores;
    public:
        // CONSTRUCTORES
        PartidaMultijugador();
        PartidaMultijugador(DtFechaHora *, float, bool,Jugador*,Jugador **);
        PartidaMultijugador(PartidaMultijugador *);
        // DESTRUCTOR
        ~PartidaMultijugador();
        // SETTERS
        void settransmitidaEnVivo(bool);
        void setCantJugadores(int);
        // GETTERS
        bool gettransmitidaEnVivo();
        Jugador ** getJugadores();
        int darCantJugadores();
        float darTotalHorasParticipantes();
        DtJugador ** getDtJugadores(); 
        string* getNickJugadores();
        
};

#endif
