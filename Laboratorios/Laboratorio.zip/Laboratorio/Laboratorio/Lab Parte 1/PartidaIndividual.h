#ifndef PARTIDAINDIVIDUAL_H
#define PARTIDAINDIVIDUAL_H
#include "Partida.h"
#include "Jugador.h"
#include <string>

using namespace std;

class PartidaIndividual : public Partida{
    private:
        // ATRIBUTOS
        bool continuaPartidaAnterior;
    public:
        // CONSTRUCTORES
        PartidaIndividual();
        PartidaIndividual(DtFechaHora *, float, bool,Jugador *);
        PartidaIndividual(PartidaIndividual *);
        // DESTRUCTOR
        ~PartidaIndividual();
        // SETTERS
       	void setcontinuaPartidaAnterior(bool);
        // GETTERS
        bool getcontinuarPartidaAnterior();
        //metodos
        float darTotalHorasParticipantes();
};

#endif
