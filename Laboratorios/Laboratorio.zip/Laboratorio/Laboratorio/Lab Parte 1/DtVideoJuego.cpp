#include "DtVideoJuego.h"

DtVideoJuego::DtVideoJuego(){
	this->titulo="";
	this->genero=Otro;
	this->totalHorasDeJuego = 0;
}

DtVideoJuego::DtVideoJuego(string _titulo,TipoJuego _tipoJuego,float horasJuego){
	this->genero = _tipoJuego;
	this->titulo = _titulo;
	this->totalHorasDeJuego = horasJuego;
}

string DtVideoJuego::getTitulo(){
	return this->titulo;
}

float DtVideoJuego::getTotalHorasDeJuego(){
	return this->totalHorasDeJuego;
}

TipoJuego DtVideoJuego::getGenero(){
	return this->genero;
}
