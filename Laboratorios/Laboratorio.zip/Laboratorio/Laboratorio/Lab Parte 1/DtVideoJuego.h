#ifndef DT_VIDEO_JUEGO
#define DT_VIDEO_JUEGO
#include <string.h>
#include <iostream>
#include "EnumTipoJuego.h"

using namespace std;

class DtVideoJuego{
	private:
		string titulo;
		TipoJuego genero;
		float totalHorasDeJuego;
	public:
		DtVideoJuego();
		DtVideoJuego(string,TipoJuego,float);
		string getTitulo();
		float getTotalHorasDeJuego();
		TipoJuego getGenero();
};

#endif
