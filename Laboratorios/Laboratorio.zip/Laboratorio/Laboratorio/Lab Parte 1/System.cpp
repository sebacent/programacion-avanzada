#include "System.h"

System::System(){
   	this->mis_videojuegos = new VideoJuego * [MAX_VIDEOJUEGOS];
    this->cantVideojuegos = 0;
    this->mis_jugadores = new Jugador * [MAX_JUGADORES];
    this->cantJugadores = 0;
}

void System::agregarJugador(string _nickname ,int _edad,string _contrasenia){
    // Controlamos que no exista ese usuario
    for (int i = 0; i < this->cantJugadores; i++){
        if (mis_jugadores[i]->getnickname() == _nickname)
            throw std::invalid_argument("El Jugador ya existe");
    }
    // Se crea el jugador y se agrega
    if(cantJugadores < MAX_JUGADORES){
    	Jugador * nuevoJugador = new Jugador(_nickname,_edad,_contrasenia);
    	mis_jugadores[this->cantJugadores] = nuevoJugador;
    	this->cantJugadores++;
	}else{
		cout<<"El sistema ya alcanzo el limite de jugadores"<<endl;
	}
    
}

void System::agregarVideoJuego(string _nombre ,TipoJuego _genero){
    // Controlamos que no exista ese VideoJuego
    for (int i = 0; i < this->cantVideojuegos; i++){
        if (mis_videojuegos[i]->getNombre() == _nombre)
            throw std::invalid_argument("El VideoJuego ya existe");
    }
    // Se crea el VideoJuego y se agrega
    if(cantVideojuegos < MAX_VIDEOJUEGOS){
    	VideoJuego * nuevoVideoJuego = new VideoJuego(_nombre,_genero);
    	mis_videojuegos[this->cantVideojuegos] = nuevoVideoJuego;
    	this->cantVideojuegos++;
	}else{
		cout<<"El sistema ya alcanzo el limite de videojuegos"<<endl;
	}
    
}

DtJugador** System::obtenerJugadores(int& cantJugadores){
	cantJugadores = this->cantJugadores;
	
	if(cantJugadores == 0){
		return NULL;
	}
	DtJugador** res =  new DtJugador*[cantJugadores];
	//Jugador* j;
	for(int i = 0; i < cantJugadores;i++){
		res[i] = mis_jugadores[i]->devolverDt();
	}
	return res;
}

DtVideoJuego ** System::obtenerVideoJuegos(int& cantVideojuegos){
	
	cantVideojuegos = this->cantVideojuegos;
	if(cantVideojuegos == 0){
		return NULL;
		
	}
	DtVideoJuego** res = new DtVideoJuego*[cantVideojuegos];
	
	for(int i = 0; i < cantVideojuegos ;i++){
		res[i] = mis_videojuegos[i]->devolverDt();
	} 
	
	return res;
}

void System::iniciarPartida(string nickname,string nombreVideojuego,DtPartida* datos){
	bool validoJuego = false;
	bool validoJugador = false;
		DtPartidaMultijugador * pm = dynamic_cast<DtPartidaMultijugador*>(datos);
		if(pm){
			for (int i = 0; i < this->cantVideojuegos; i++){
				VideoJuego * vj = this->mis_videojuegos[i];
				if(vj->getNombre() == nombreVideojuego){
					validoJuego = true;
					for (int j = 0; j < this->cantJugadores; j++){
						Jugador * ju = this->mis_jugadores[j];
						if(ju->getnickname() == nickname){
							validoJugador = true;
							Jugador ** jugadoresUnidos = obtenerJugadoresDesdeNick(pm->getJugadores(),pm->getCantJugadores());
							PartidaMultijugador * partida = new PartidaMultijugador(pm->getFecha(),pm->getDuracion(),pm->getTransmitidaEnVivo(),ju,jugadoresUnidos);
							if(vj->agregarPartida(partida)){
								cout<<"La partida se inicio correctamente"<<endl;
							}else{
								cout<<"Error al iniciar partida"<<endl;
							}
						}
					}if(this->cantJugadores == 0){
						cout<<"No hay jugadores agregados"<<endl;
					}
				}
			}if(this->cantVideojuegos == 0){
				cout<<"No hay juegos agregados"<<endl;
			}
		}else{
			DtPartidaIndividual * pi = dynamic_cast<DtPartidaIndividual*>(datos);
			for (int i = 0; i < this->cantVideojuegos; i++){
				VideoJuego * vj = this->mis_videojuegos[i];
				if(vj->getNombre() == nombreVideojuego){
					validoJuego = true;
					for (int j = 0; j < this->cantJugadores; j++){
						Jugador * ju = this->mis_jugadores[j];
						if(ju->getnickname() == nickname){
							validoJugador = true;
							PartidaIndividual * partida = new PartidaIndividual(pi->getFecha(),pi->getDuracion(),pi->getContinuarPartidaAnterior(),ju);
							if(vj->agregarPartida(partida)){
								cout<<"La partida se inicio correctamente"<<endl;
							}else{
								cout<<"Error al iniciar partida"<<endl;
							}
						}else if(j == cantJugadores-1 && ju->getnickname() != nickname || nickname == ""){
							throw std::invalid_argument("El jugador "+nickname+" no existe");
						}
					}if(this->cantJugadores == 0){
						cout<<"No hay jugadores agregados"<<endl;
					}
				}else if(i == cantVideojuegos-1 && vj->getNombre() != nombreVideojuego || nombreVideojuego == ""){
					throw std::invalid_argument("El video juego "+nombreVideojuego+" no existe");
				}
			}if(this->cantVideojuegos == 0){
				cout<<"No hay juegos agregados"<<endl;
			}
		}
		
		if(!validoJuego){
			cout<<"Error al encontrar el juego"<<endl;
		}
		
		if(!validoJugador){
			cout<<"Error al encontrar al jugador"<<endl;
		}
}

DtPartida** System::obtenerPartidas(string videojuego, int& cantPartidas){
	DtPartida ** r = NULL;
	if(this->cantVideojuegos != 0){
		for (int i = 0; i < this->cantVideojuegos; i++){
			VideoJuego * vj = this->mis_videojuegos[i];
			if(vj->getNombre() == videojuego){
				vj = this->mis_videojuegos[i];
				cantPartidas = vj->getCantPartidas();
				if(vj->getCantPartidas() != 0){
					r = vj->getDtPartidas();
					return r;
				}else{
					cout<<"El videojuego no tiene partidas"<<endl;
				}
			}else if(this->cantVideojuegos == i-1){
				throw std::invalid_argument("El VideoJuego no existe");
			}
    	}
	}
}


Jugador ** System::obtenerJugadoresDesdeNick(string * jugadores,int cantJugadoresAgregados){
	if(cantJugadores != 0){
		Jugador ** res = new Jugador*[cantJugadoresAgregados];
		for(int i = 0; i < cantJugadoresAgregados; i++){
			for(int i =0;i<cantJugadores; i++){
				if(mis_jugadores[i]->getnickname() == jugadores[i]){
					res[i] = mis_jugadores[i];
				}
			}
		}
		return res;
	}else{
		return NULL;
	}
}

bool System::estaEnArray(int* arr,int cantItems,int aBuscar){
	for(int i = 0;i < cantItems;i++){
		if(arr[i] == aBuscar){
			return true;
		}else{
			if(i == cantItems-1){
				return false;
			}
		}
	}
}

int System::getCantVideoJuegos(){
    return this->cantVideojuegos;
}
int System::getCantJugadores(){
    return this->cantJugadores;
}
int& System::getCantVideoJuegosA(){
    return (int&)this->cantVideojuegos;
}
int& System::getCantJugadoresA(){
    return (int&)this->cantJugadores;
}



