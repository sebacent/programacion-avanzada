#include "DtJugador.h"

DtJugador::DtJugador(){
	this->edad = 0;
	this->nickname = "a";
}

DtJugador::DtJugador(string nick,int edad){
	this->edad = edad;
	this->nickname = nick;
}

string DtJugador::getNickname(){
	return this->nickname;
}

int DtJugador::getEdad(){
	return this->edad;
}
