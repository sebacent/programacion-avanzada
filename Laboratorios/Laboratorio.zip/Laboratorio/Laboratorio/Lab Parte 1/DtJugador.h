#ifndef DT_JUGADOR
#define DT_JUGADOR
#include <iostream>
using namespace std;

class DtJugador{
	private:
		string nickname;
		int edad;
	public:
		DtJugador();
		DtJugador(string,int);
		string getNickname();
		int getEdad();
};

#endif
