#ifndef DT_PARTIDA_INDIVIDUAL
#define DT_PARTIDA_INDIVIDUAL
#include "DtPartida.h"
#include <iostream>

class DtPartidaIndividual:public DtPartida{
	private:
		bool continuarPartidaAnterior;
	public:
		DtPartidaIndividual();
		DtPartidaIndividual(bool,DtFechaHora *,float,DtJugador*);
		//destruc
		~DtPartidaIndividual(){};
		//getters
		bool getContinuarPartidaAnterior();
		//sobrecarga
        void imprimir(ostream&);
};	
#endif
