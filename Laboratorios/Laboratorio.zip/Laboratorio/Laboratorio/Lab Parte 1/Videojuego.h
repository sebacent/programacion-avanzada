#ifndef VIDEOJUEGO_H
#define VIDEOJUEGO_H
#include "EnumTipoJuego.h"
#include <iostream>
#include "Partida.h"
#include "DtVideoJuego.h"
#include "DtPartida.h"
#include "DtPartidaMultijugador.h"
#include "DtPartidaIndividual.h"
#include "PartidaMultijugador.h"
#include "PartidaIndividual.h"
#define MAX_PARTIDAS 5

using namespace std;

class VideoJuego{
	private:
		//Atributos
		string nombre;
		TipoJuego genero;
		Partida ** mis_partidas;
		unsigned cantPartidas;
		public:
		//Constructor
		VideoJuego();
		VideoJuego(string, TipoJuego);
		VideoJuego(VideoJuego *);
		// Destructor
		~VideoJuego();
		// Setters
		void setNombre(string);
		void setGenero(TipoJuego );
		// Getters
		string getNombre();
		TipoJuego getGenero();
		DtVideoJuego* devolverDt();
		DtPartida ** getDtPartidas();
		int getCantPartidas();
		//metodos
		bool agregarPartida(Partida*);
};

#endif
 
 
