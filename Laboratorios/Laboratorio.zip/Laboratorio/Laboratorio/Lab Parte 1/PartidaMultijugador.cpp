#include "PartidaMultijugador.h"

//CONSTRUCTORES
PartidaMultijugador::PartidaMultijugador() : Partida(){
	this->transmitidaEnVivo = false;
	this->jugadores = new Jugador*[MAX_JUGADORES];
	
	for(int i =0; i<= MAX_JUGADORES ; i++){
		jugadores[i] = NULL;
	}
};


PartidaMultijugador::PartidaMultijugador(DtFechaHora * _hora, float _duracion, bool _transmitidaEnVivo,Jugador * jugador,Jugador ** jugadoresConectados) : Partida( _hora, _duracion,jugador){
	this->transmitidaEnVivo = _transmitidaEnVivo;
	this->transmitidaEnVivo = false;
	this->jugadores = jugadoresConectados;
	jugadores[0] = jugador;
	this->cantJugadores =1;
}
PartidaMultijugador::PartidaMultijugador(PartidaMultijugador *) : Partida(){

};

// DESTRUCTOR
PartidaMultijugador::~PartidaMultijugador(){
};


//SETTERS
void PartidaMultijugador::settransmitidaEnVivo(bool _transmitidaEnVivo){
	this->transmitidaEnVivo = _transmitidaEnVivo;
};
void PartidaMultijugador::setCantJugadores(int a){
	this->cantJugadores =a;
}

//GETERS
bool PartidaMultijugador::gettransmitidaEnVivo(){
	return this->transmitidaEnVivo;
};

Jugador ** PartidaMultijugador::getJugadores(){
	return this->jugadores;
}

int PartidaMultijugador::darCantJugadores(){
	return this->cantJugadores;
}

float PartidaMultijugador::darTotalHorasParticipantes(){
	int i = darCantJugadores();
	return (i+1)*this->getDuracion();
}

DtJugador ** PartidaMultijugador::getDtJugadores(){
	if(this->cantJugadores !=0){
		DtJugador ** res = new DtJugador*[this->cantJugadores];
		Jugador * j;
		for(int i = 0;i<this->cantJugadores;i++){
			res[i] = this->jugadores[i]->devolverDt();
		}
		return res;
	}else{
		return NULL;
	}
}

string* PartidaMultijugador::getNickJugadores(){
	if(this->cantJugadores !=0){
		string* res = new string[this->cantJugadores];
		for(int i = 0;i<this->cantJugadores;i++){
			res[i] = this->jugadores[i]->getnickname();
		}
		return res;
	}else{
		return NULL;
	}
}



