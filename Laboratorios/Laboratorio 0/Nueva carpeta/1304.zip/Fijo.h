// #ifndef FIJO_H
// #define FIJO_H
// //#include "Empleado.h"
// #include <string>
// class Empleado;
// class Empresa;

// class Fijo : public Empleado {
//     public:
//         Fijo(std::string nombre, std::string ci, int edad, Paga valor_hora, Empresa *miemp);
//         ~Fijo();
//         void imprimirFijo();
//         float getSueldoPeso();
//         float getSueldoDolar();

// };

// #endif