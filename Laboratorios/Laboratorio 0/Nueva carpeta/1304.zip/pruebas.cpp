//#include"lab0.h"
#include<stdio.h>
#include<iostream>
#include "Empresa.h"
#include "Paga.h"
#include "Fijo.h"
#include "Jornalero.h"
#include "Empleado.h"

using namespace std;

int main(){ 
    // LOS ERRORES QUE TIENE ES PORQUE NO ESTAN COMPILADOS LOS .CPP DE CADA CLASE 
    // HAY QUE VER COMO SE COMPILA CADA CPP Y COMO EJECUTAR ESTE 
    // https://stackoverflow.com/questions/43447960/error-message-undefined-reference-error-to-in-c



    // FALTA:MENU, POR LO TANTO TAMBIEN MANEJO DE EXCEPCIONES, SOBRECARGA, CARGAR ARRAYS DE PUNTEROS CON EMPLEADOS
    Empresa pruebaEmpresa = Empresa();
    
    string nombre_empleado = " JORGE";
    string nombre_legal = " EMRESARIO";
    string ci = "50151411";
    int edad = 22;
    Paga valor = Paga(185.8,Moneda::US);
    // cout<<valor.getMoneda()<< endl;
    // cout<<valor.getMonto()<<endl;
    // valor.setMoneda(Moneda::USD);
    // valor.setMonto(177.58);    


   // int rut = 158451;

    Fijo* empFij = new Fijo(nombre_empleado,ci,edad,valor,&pruebaEmpresa);
      try {
        double sueldoPrueba = empFij->getPaga();
        cout<<"SUELDO PRUEBA"<<endl;
        cout<<sueldoPrueba<<endl;
    } catch (...) {
        cout << "Ocurrió una excepción" << endl;
    }

     
    // cout<< "LLEGGOOOOOOOOOO2"    <<endl;
    // float monto = prueba.getMonto();
    // cout<< "LLEGGOOOOOOOOOO3"    <<endl;
    // if (monto != 0)
    //     cout << monto <<endl;
    // cout<< "LLEGGOOOOOOOOOO4"    <<endl;
    // cout << prueba.getMonto() <<endl;
    // cout<< "LLEGGOOOOOOOOOO5"    <<endl;
    // cout << prueba.getMoneda()<<endl;
    // cout<< "LLEGGOOOOOOOOOO6"    <<endl;
    // cout<<empFij->getSueldoPeso()<<endl;
    // empFij->imprimirEmpleado();
    
    ci = "8888888";
    nombre_empleado = " RAUL";
    cout<< "Nombre empleado"<< nombre_empleado<<endl;

     try {
            cout<<pruebaEmpresa.getNombre()<<endl;
            Fijo* fij = new Fijo(nombre_empleado, ci, edad, valor,&pruebaEmpresa);
            fij->imprimirEmpleado();

    } catch (...) {
        cout << "Ocurrió una excepción" << endl;
    }

   
    

    Paga val2 = Paga(129,US);
    ci = "99999999";
    nombre_empleado = " PEDRO";
    Jornalero* jorna = new Jornalero(nombre_empleado, ci, edad, val2,50,&pruebaEmpresa);
    jorna->setHoras(100);
    jorna->imprimirEmpleado();

    pruebaEmpresa.AddEmpleado(empFij);
   //pruebaEmpresa.AddEmpleado(fij);
    pruebaEmpresa.AddEmpleado(jorna);
    pruebaEmpresa.listarEmpleados();    


    return 0;
}